This program is used to deal with Josephus Problem in the way of single linked list.
For using single linked list, the linked list must be inverse in left direction.

This program will free all pointer malloced. 
Therefore, this program can be execute several times.
