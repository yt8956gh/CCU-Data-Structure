The program is used to realize the game named "6 Nimmit!"

The game rule:
    (1) The card is numbered from 1 to 104. No duplicate numbers will appear.
    (2) There are four rows. Every row holds up to five cards.
    (3) For each turn, the player with smaller card's number has higher priority todiscard.
    (4) Each player has 66 points initially.
    (5) If the player places the fifth card in a row, he/she will lose 4 points.
    (6) If the player discard the card number which is smaller than all cards in all rows,he/she claims all    cards in the row which has fewest cards. However, if every row has the same amount of cards, the player should claim all cards in the row which has the smallest card number.

Notes:
1. This program will read a file named "input.txt" and write a file named "result.txt".
2. There are three sort algorithms(selction,insertion and quick) to order players' cards in every turn.

