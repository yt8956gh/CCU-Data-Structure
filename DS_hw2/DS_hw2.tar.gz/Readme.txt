毛胤年 資工2B 405410010

The way that I realize Stack is using 
    (1) push function to get mouse from queue "mouse[0] & mouse[1]" 
    (2) poping mouse with asign mouse back to queue "mouse[0] & mouse[1]" and set the empty space to 0.

The way that I realize Queue is using
    (1) pop_Q function to move the queue in the condition that first element is removed

